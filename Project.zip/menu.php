<nav class="p-1 bg-black shadow md:flex md:items-center md:justify-between">
    <div class="flex justify-between items-center">
      <image class="cursor-pointer duration-500 px-4 py-2 hover:bg-red-600 rounded w-30 h-20" src="https://cdn.dribbble.com/users/2348/screenshots/10696082/media/4a24583ea649f9df1415775a37c84ae5.png?compress=1&resize=1000x750&vertical=top"></image>
      <span class="text-3xl cursor-pointer mx-2 md:hidden block">
        <ion-icon name="menu" onclick="Menu(this)"></ion-icon>
      </span>
    </div>
    <ul class="md:flex md:items-center z-[-1] md:z-auto md:static absolute bg-black w-full left-0 md:w-auto md:py-1 py-4 md:pl-2 pl-7 md:opacity-100 opacity-0 top-[-400px] transition-all ease-in duration-500">
      <li class="mx-4 my-6 md:my-0">
        <a href="index.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">HOME</a>
      </li>
      <li class="mx-4 my-6 md:my-0">
        <a href="page1.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">ABOUT</a>
      </li>
      <li class="mx-4 my-6 md:my-0">
        <a href="page2.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">AGENT</a>
      </li>
      <li class="mx-4 my-6 md:my-0">
        <a href="page3.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">MAP</a>
      </li>
      <li class="mx-4 my-6 md:my-0">
        <a href="page4.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">WEAPON</a>
      </li>
      <li class="mx-4 my-6 md:my-0">
        <a href="skin_list.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">SKIN</a>
        <li class="mx-4 my-6 md:my-0">
        <a href="skin1_list.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">BATTLEPASS ACT1</a>
        <li class="mx-4 my-6 md:my-0">
        <a href="skin2_list.php" class="bg-black text-1xl text-white duration-700 px-6 py-2 mx-1 hover:bg-red-500 rounded">BATTLEPASS ACT2</a>
        
  </nav>