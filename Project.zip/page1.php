<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" type="text/css" href="mystyle1.css">
</head>

 <body class="bg-gray-800 mb-36">
  <?php include 'menu.php'; ?>

  <header>
    <div class="text-6xl text-center font-extrabold p-8">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h3 class="animate-charcter">ABOUT</h3>
          </div>
        </div>
      </div>
    </div>
</header>

<div class="flex justify-center items-center">
  <div class="shadow-2xl h-3/5 w-3/5 p-6 text-justify text-white text-2xl font-bold">นี่คือคู่มือสำหรับผู้เริ่มเล่น VALORANT  
    ที่ส่งตรงมาจากไฟล์ของ Brimstone
    ไม่ว่านี่จะเป็นการรับหน้าที่ครั้งแรกหรือการทบทวนความจำอีกครั้งของคุณเราคิดว่าการเรียนรู้จากเอเจนท์ที่เคยมีประสบการณ์มาก่อนนั้นคือวิธีการที่ดีที่สุดด้านล่างนี้คือสิ่งที่ควรรู้ก่อนการเล่นเกมครั้งแรกของคุณตั้งใจอ่านให้ดีล่ะคุณอาจจะได้เรียนรู้อะไรบางอย่าง</div>
  </div>
      <div class="flex justify-center items-center mt-10">
        <img class="w-2/5 h-2/5 flex justify-center item-center m-26" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/bltc6926f5b584b218d/5ed56f37c94d6c5071a310b3/WIV_1_Intro_WiV-tha.jpg" alt="">
      </div>

      <div class="flex justify-center items-center">
        <div class="shadow-2xl box-content h-3/5 w-3/5 p-6 text-center text-white text-1xl">
            ก่อนที่คุณจะเข้าสู่รอบแรก คุณจะได้เลือกเอเจนท์จากรายชื่อที่มีให้ แต่ละตัวจะมีบทบาทและ
            ทักษะพิเศษที่ออกแบบมาเพื่อการทำงานร่วมกันและนำไปสู่ชัยชนะ 
            คุณสามารถเรียนรู้ข้อมูลเชิงลึกของเอเจนท์แต่ละตัวได้ในหน้าเอเจนท์ของเรา</div>
        </div>
      <div class="flex justify-center items-center mt-10">
        <img class="w-2/5 h-2/5 flex justify-center item-center m-26" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt602806eb18c814cf/61f0d8a86fb4a052ac928c06/WIV_2_Roles_updated_TH.jpg" alt="">
      </div>
      <div class="flex justify-center items-center">
        <div class="shadow-2xl box-content h-3/5 w-3/5 p-6 text-center text-white text-1xl">
          หลังจากที่ทุกคนเลือกเอเจนท์แล้ว (โอ้ คุณเลือกตัวนั้นรึ) คุณจะได้เข้าสู่แผนที่แบบสุ่มและเข้าสู่การแข่งขันรอบแรกอย่างเป็นทางการ
          เริ่มต้นรอบโดยในฐานะผู้โจมตีหรือผู้ป้องกัน และจะสับเปลี่ยนฝ่ายในระหว่างนั้น แต่ก่อนอื่น คุณจะต้องสำรวจช่วงการซื้อที่จะทำให้คุณสามารถ
          ซื้ออาวุธและสกิลต่างๆ ได้ สิ่งที่คุณซื้อจะกำหนดชัยชนะของคุณ ให้สไตล์หรือการจับคู่เป็นแนวทางในการเลือกของคุณ</div>
        </div>
          <div class="flex justify-center items-center mt-10">
            <img class="w-2/5 h-2/5 flex justify-center item-center m-26" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/bltbb32b59a9ed0d6bc/5ed5702f859dd01a62689aa3/WIV_3_Round-tha.jpg" alt="">
          </div>

          <div class="flex justify-center items-center">
            <div class="shadow-2xl box-content h-3/5 w-3/5 p-6 text-center text-white text-1xl">
              จะไม่มีใครบอกวิธีการใช้เงินกับคุณ และคุณก็จะต้องตัดสินใจใช้เงินในบาง
              ครั้งเรามีปืนพร้อมสำหรับทุกสถานการณ์และ
              คุณสามารถอ่านรายละเอียดของอาวุธแต่ละชนิดได้ในหน้าคลังแสงของเรา 
              หากมีข้อสงสัย ลองซื้อตามประเภทของอาวุธและดูว่ามันเหมาะกับสไตล์ 
              ความเชี่ยวชาญและกลยุทธ์ของทีมของคุณหรือไม่</div>
            </div>
              <div class="flex justify-center items-center mt-10">
                <img class="w-2/5 h-2/5 flex justify-center item-center m-26" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt88010df5928fe7ab/5ed57cfdc94d6c5071a310df/WIV_4_WEAPONS-tha.jpg" alt="">
              </div>

      <footer class="bg-black text-center text-white text-1xl p-6 w-full fixed bottom-0">
    <h1>©2022 Passakorn</h1>
  </footer>

</body>
</html> 
