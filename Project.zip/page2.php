<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" type="text/css" href="mystyle1.css">
</head>
 <body class="bg-gray-800 mb-36">
 <?php include 'menu.php'; ?>

  <header>
    <div class="text-6xl text-center font-extrabold p-6">
      <div class="container">
        <div class="row">
          <div class="text-center">
            <h3 class="animate-charcter">AGENT</h3>
          </div>
        </div>
      </div>
    </div>
</header>

  <div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full h-96" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt8a627ec10b57f4f2/5eb7cdc16509f3370a5a93b7/V_AGENTS_587x900_sage.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">SAGE</div>
          <p class="text-white text-base">
            Sage จากประเทศจีน เธอเป็น Sentinel ผู้เชี่ยวชาญด้านการรักษาทั้งสำหรับตัวเธอเองและทีม โดยที่ Sage จะใช้ความสุขุมของเธอเพื่อช่วยให้ทีมร่วมกันลงมือ
          </p>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full h-96" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt26fcf1b5752514ee/5eb7cdbfc1dc88298d5d3799/V_AGENTS_587x900_Brimstone.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">BRIMSTONE</div>
          <p class="text-white text-base">
            เอเจนต์หนุ่มใหญ่ผู้เป็นทั้งผู้ควบคุมและผู้บังคับบัญชาจากสหรัฐอเมริกาคนนี้ มักแสดงให้เห็นว่าเขามีความได้เปรียบในการต่อสู้อยู่เสมอ โดยเฉพาะอย่างยิ่งเวลาที่มีอาวุธยทโธปกรณ์หมุนเวียนอยู่รอบๆ
          </p>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full h-96" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/bltf0200e1821b5b39f/5eb7cdc144bf8261a04d87f9/V_AGENTS_587x900_Phx.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">PHOENIX</div>
          <p class="text-white text-base">
            เอเจนต์หนุ่มเลือดนักสู้จากสหราชอาณาจักรคนนี้ สามารถจุดไฟในสนามรบ พร้อมกับแสงสว่างวาบและพลังแห่งเปลวเพลิง ระเบิดลูกไฟของ Phoenix ก่อให้เกิดดาเมจแต่ก็สามารถฮีลเขาได้ในเวลาเดียวกัน          </p>
        </div>
    </div>
</div>
<div class="flex justify-center items-center flex-auto">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full h-96" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/bltf11234f4775729b7/5ebf2c275e73766852c8d5d4/V_AGENTS_587x900_ALL_Sova_2.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">SOVA</div>
          <p class="text-white text-base">
            เอเจนต์หนุ่มชาวรัสเซียคนนี้ มีศักยภาพในการโจมตีอย่างไร้ความปราณี ทั้งในการติดตามและกำจัดศัตรูของเขา ไม่มีใครหลบซ่อนจากคุนธนูเขาไปได้หรอกนะ</p>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full h-96" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/bltc825c6589eda7717/5eb7cdc6ee88132a6f6cfc25/V_AGENTS_587x900_Viper.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">VIPER</div>
          <p class="text-white text-base">
            Viper นักเคมีชาวอเมริกัน เธอเชี่ยวชาญด้านการใช้อุปกรณ์ทำมาจากสารเคมีที่เป็นพิษต่างๆเป็นอย่างมาก รวมถึงสงครามจิตที่เธอถนัดเพื่อทำลายล้างศัตรูให้สิ้นซาก</p>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full h-96" src="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt158572ec37653cf3/5eb7cdc19df5cf37047009d1/V_AGENTS_587x900_Cypher.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">CYPHER</div>
          <p class="text-white text-base">
            Cypher เป็นสมาชิกจากเครือข่ายในโมร็อกโก หากข้อมูลต่างๆเอเจนต์คนนี้เหมาะกับคุณเป็นอย่างมากเลยทีเดียว เขามีความสามารถในการจับกุม และเปิดเผยตำแหน่งของศัตรูที่ติดอยู่ในกับดักของเขา</p>
        </div>
    </div>
</div>

  <footer class="bg-black text-center text-white text-1xl p-6 w-full fixed bottom-0">
    <h1>©2022 Passakorn</h1>
  </footer>

</body>
</html> 
