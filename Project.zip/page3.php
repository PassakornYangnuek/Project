<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" type="text/css" href="mystyle1.css">
</head>
 <body class="bg-gray-800 mb-36">
 <?php include 'menu.php'; ?>

  <header>
    <div class="text-6xl text-center font-extrabold p-6">
      <div class="container">
        <div class="row">
          <div class="text-center">
            <h3 class="animate-charcter">MAP</h3>
          </div>
        </div>
      </div>
    </div>
</header>
  <div class="flex justify-center items-center">
      <div class="h-3/6 w-3/6 border-sky-500 text-center">
        <img class="rounded-md" src="https://cdn1.dotesports.com/wp-content/uploads/2020/06/09091543/Ascent-2-1.png" alt="Sunset in the mountains">
      </div>

          <div class="h-2/5 w-2/5 p-8 ml-8 text-center text-white text-1xl border-double border-sky-800 border-4 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-md">
            <div class="text-center text-3xl font-bold text-red-500">ASCENT</div>
              <div div class="text-center pt-3">ลานกว้างสำหรับสงครามยิ้บย้อยเพื่อชิงตำแหน่งและความได้เปรียบ 
                                               ได้แยกสนามออกเป็นสองส่วนบน 
                                            Ascent แต่ละจุดสามารถเสริมการป้องกันด้วยประตูระเบิดที่หมุนกลับไม่ได้
                                           เมื่อประตูมันหล่นลงมาแล้ว คุณต้องทำลายมันหรือหาทางอื่น 
                                           ยอมสละอาณาเขตให้น้อยที่สุดเท่าที่จะเป็นไปได้
                                          </div>
                                          </div>
                                        </div>
              <div class="flex justify-center items-center pt-12 ">
                <div class="h-3/6 w-3/6 border-sky-500 text-center">
                  <img class="rounded-md " src="https://static0.gamerantimages.com/wordpress/wp-content/uploads/2022/10/Featured---Valorant-Guide-to-the-Haven-Map.jpg" alt="Sunset in the mountains">
                </div>
                    <div class="h-2/5 w-2/5 p-8 ml-8 text-center text-white text-1xl border-double border-4 border-sky-800 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-md">
                            <div class="text-center text-3xl font-bold text-red-500">HAVEN</div>
                              <div class="text-center pt-3">ภายใต้อารามที่ถูกลืม 
                              เสียงโห่ร้องดังขึ้นจากเอเจนท์
                              คู่ปรับที่กำลังปะทะกันเพื่อควบคุมทั้งสามจุด
                              และพื้นที่ให้เข้ายึดควบคุมอีกมาย 
                              แต่ฝ่ายป้องกันสามารถใช้สิ่งก่อสร้างเหล่านี้เพื่อช่วยในการบุกเข้าไปอย่างดุดัน</div>
                                 </div>
                                  </div>

                    <div class="flex justify-center items-center pt-12">
                      <div class="h-3/6 w-3/6 border-sky-500 text-center">
                        <img class="rounded-md" src="https://imageio.forbes.com/specials-images/imageserve/63b845e67098373db7429d7b/0x0.jpg?format=jpg&width=1200" alt="Sunset in the mountains">
                      </div>
                          <div class="h-2/5 w-2/5 p-8 ml-8 text-center text-white text-1xl border-double border-4 border-sky-800 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-md">
                            <div class="text-center text-3xl font-bold text-red-500">SPLIT</div>
                            <div class="text-center pt-3"> หากคุณต้องการไปให้สุด คุณต้องไปด้านบน 
                            จุดวางระเบิดทั้งสองที่ถูกแยกโดยพื้นที่ส่วนกลางที่ยกระดับขึ้น 
                            จะช่วยให้เคลื่อนทัพได้อย่างรวดเร็วโดยการใช้เชือกสองเส้นดึงตัวขึ้นมา 
                            ต่ละจุดมาพร้อมกับหอคอยสำหรับการควบคุมพื้นที่ อย่าลืมแหงนหน้ามองขึ้นไปดูก่อนที่กระสุนจะลอยลงมาล่ะ
                          </div>
                          </div>
                    </div>
                          <div class="flex justify-center items-center pt-12">
                            <div class="h-3/6 w-3/6 border-sky-500 text-center">
                              <img class="rounded-md" src="https://cdn.esportsdriven.com/media/guides/images/bind_ekhbkMM.main.jpg" alt="Sunset in the mountains">
                            </div>
                                <div class="h-2/5 w-2/5 p-8 ml-8 text-center text-white text-1xl border-double border-4 border-sky-800 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-md">
                                  <div class="text-center text-3xl font-bold text-red-500">BIND</div>
                                    <div class="text-center pt-3">สองจุด ไม่มีตรงกลาง ต้องเลือกซ้ายหรือขวา จะเลือกทางไหนดี? 
                                  ทั้งสองจุดมีเส้นทางตรงสำหรับฝ่ายโจมตีและมีเครื่องเทเลพอร์ตทาง
                                  เดียวจำนวนสองเครื่อง ทำให้การขนาบข้างนั้นง่ายขึ้น
                                </div>
                                </div>
                             </div>
  <footer class="bg-black text-center text-white text-1xl p-6 w-full fixed bottom-0">
    <h1>©2022 Passakorn</h1>
  </footer>

</body>
</html> 
       
