<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" type="text/css" href="mystyle1.css">
</head>
 <body class="bg-gray-800 mb-36">
 <?php include 'menu.php'; ?>

  <header>
    <div class="text-6xl text-center font-extrabold p-8">
      <div class="container">
        <div class="row">
          <div class="text-center">
            <h3 class="animate-charcter">WEAPON</h3>
          </div>
        </div>
      </div>
    </div>
</header>
<div class="flex justify-center items-center pt-12 ">
      <div class="h-2/5 w-2/5 p-8 ml-8 text-center text-white text-1xl border-double border-4 border-sky-800 bg-gradient-to-r from-indigo-500 to-blue-600 rounded-md">
              <div class="text-center text-2xl font-bold"></div>
                <div class="text-center pt-3 text-2xl font-bold">Valorant ถือเป็นเกม FPS หน้าใหม่มาแรงที่มีระบบเกมเพลย์อันหน้าตื่นตาตื่นใจทั้งการเลือกใช้งานเอเจนท์ 
                  ให้ครบทุกสายภายในทีมการใช้งานสกิลเพื่อแก้ทางกับศัตรู แต่ทว่าความสำคัญของเกม Valorant ไม่ใช่เพียงการใช้งานสกิลเท่านั้นเพราะอาวุธ”ปืน”คือหัวใจสำคัญของเกมดังนั้นผู้เล่นจะต้องมาทำความเข้าใจในประเภทของปืนที่เหมาะสมกับทั้งแผนที่ตำแหน่งของเอเจนท์หรือแม้กระทั่งตำแหน่งการยืนที่ผู้เล่นจะปลิดชีพศัตรูได้อย่างไม่มีผิดพลาด</div>
                   </div>
                    </div>
                <div class="flex-col text-center text-white mt-12">
                  <p class="mb-6 text-2xl">เริ่มต้นด้วยประเภทของปืน (เฉพาะอาวุธปืนเท่านั้น) แบ่งเป็น 6 ประเภท</p>
                 
                  <p class="mb-6"> 1. ปืนพก (SIDEARMS) 5 กระบอก</p>
                  
                  <p class="mb-6"> 2. ปืนกลมือ (SMGS) 2 กระบอก</p>
                     
                    <p class="mb-6">  3. ปืนลูกซอง (SHOTGUNS) 2 กระบอก</p>
    
                        <p class="mb-6"> 4. ปืนไรเฟิล (RIFLES) 4 กระบอก</p>
                
                          <p class="mb-6"> 5. ปืนสไนเปอร์ไรเฟิล (SNIPERS) 2 กระบอก 
                          
                            <p class="mb-6">6. ปืนกล (HEAVIES) 2 กระบอก</p>
                          </div>
                


                        <div class="flex-col text-center text-white ml-20">
                         <p class="text-2xl text-left">Sidearms</p>
                            </div>
                          <div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-classic-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">CLASSIC</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-shorty-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">SHORTY</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/skins/full-details/valorant-standard-frenzy-weapon-skin.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">FRENZY</div> 
    </div>
</div>
</div>
<div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-ghost-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">GHOST</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-shorty-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">SHERRIFF</div>
        </div>
    </div>
    </div>
</div>

<div class="flex-col text-center text-white ml-20">
                         <p class="text-2xl text-left">SMGs</p>
                            </div>
                          <div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-stinger-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">STINGER</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-spectre-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">SPECTRE</div>
        </div>
    </div>
</div>
    <div class="flex-col text-center text-white ml-20">
                         <p class="text-2xl text-left">Shotguns</p>
                            </div>
                          <div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-bucky-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">BUCKY</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-judge-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">JUDGE</div>
        </div>
    </div>
</div>

<div class="flex-col text-center text-white ml-20">
                         <p class="text-2xl text-left">Rifles</p>
                            </div>
                          <div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-bulldog-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">BULLOG</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-guardian-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">GUARDIAN</div>
        </div>
    </div>
</div>
<div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-phantom-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">PHANTOM</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-vandal-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">VANDAL</div>
        </div>
    </div>
</div>
<div class="flex-col text-center text-white ml-20">
                         <p class="text-2xl text-left">Sniper Rifles</p>
                            </div>
                          <div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-marshal-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">MARSHAL</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-operator-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">OPERATOR</div>
        </div>
    </div>
</div>
<div class="flex-col text-center text-white ml-20">
                         <p class="text-2xl text-left">Machine guns</p>
                            </div>
                          <div class="flex justify-center items-center m-6">
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-ares-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">MARSHAL</div>
        </div>
    </div>
    <div class="max-w-sm rounded overflow-hidden shadow-lg m-4">
        <img class="w-full" src="https://vgraphs.com/images/weapons/valorant-odin-profile-icon.png" alt="Sunset in the mountains">
        <div class="px-6 py-4">
          <div class="font-bold text-xl text-red-500 mb-2">OPERATOR</div>
        </div>
    </div>
</div>
  <footer class="bg-black text-center text-white text-1xl p-6 w-full fixed bottom-0 mb-0">
    <h1>©2022 Passakorn</h1>
  </footer>
</body>
</html> 
