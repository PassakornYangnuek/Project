<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>skin1</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="../path/to/flowbite/dist/flowbite.js"></script>
  <script src="./TW-ELEMENTS-PATH/dist/js/index.min.js"></script>
  <script src="https://unpkg.com/flowbite@1.4.0/dist/flowbite.js"></script>
</head>
<body>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" type="text/css" href="mystyle1.css">
</head>
 <body class="bg-gray-800 mb-36">
    <?php include 'menu.php'; ?>

<div class="relative overflow-x-auto">
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        
        <thead class="text-xs text-1xl text-white uppercase bg-red-500">
            <tr>
                <th scope="col" class="px-8 py-4 text-xl">
                    สกินไอดี
                </th>
                <th scope="col" class="px-16 py-4 text-xl">
                    รูปภาพ
                </th>
                <th scope="col" class="px-8 py-4 text-xl">
                    ไอเท็ม
                </th>
                <th scope="col" class="px-8 py-4 text-xl">
                    เเทร็ค
                </th>
                <th scope="col" class="px-8 py-4 text-xl">
                    เทียร์
                </th>
                <th scope="col" class="px-8 py-4 text-xl">
                    ราคา
                </th>
                <th scope="col" class="px-8 py-4 text-xl">
                </th>
                <th scope="col" class="px-8 py-4 text-xl">
                    
                </th>
            </tr>
        </thead>
        

        <tbody>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                <th scope="row" class="px-2 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                <button class="relative inline-flex items-center justify-center p-3 overflow-hidden text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-purple-600 to-blue-500 group-hover:from-purple-600 group-hover:to-blue-500 hover:text-white dark:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800">
  <a href="skin1_add.php" class="relative px-5 py-2.5 transition-all ease-in duration-500 bg-white dark:bg-gray-900 rounded-md group-hover:bg-opacity-0">
      เพิ่มสกินปืน
  </a>
</button>
                <?php
                                include 'connectdb.php';
                                $sql =  'SELECT * FROM valorantskin1 order by skin1_id';
                                $result = mysqli_query($conn,$sql);
                                while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
                                    echo '<tr>';
                                    echo '<td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">' .$row['skin1_id'] . '</td>';
                                    echo '<td class="px-6 py-4"> <img src="'.$row['skin1_image'].'" width="150px"> </td>';
                                    echo '<td class="px-6 py-4">' . $row['skin1_collectionedition'] . '</td>';
                                    echo '<td class="px-6 py-4">' . $row['skin1_collection'] . '</td>';
                                    echo '<td class="px-6 py-4">' . $row['skin1_weapon'] . '</td>';
                                    echo '<td class="px-6 py-4"> <img class="w-6" src="img/Valorant_Points.png">' . $row['skin1_price'] . '</td>';
                                    echo '<td>';
                            ?>
                                <a href="skin1_edit.php?skin1_id=<?php echo $row['skin1_id'];?>" class="text-white bg-gradient-to-r from-cyan-400 via-cyan-500 to-cyan-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-cyan-300 dark:focus:ring-cyan-800 shadow-lg shadow-cyan-500/50 dark:shadow-lg dark:shadow-cyan-800/80 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">แก้ไข</a>
                                <a href="JavaScript:if(confirm('ยืนยันการลบ')==true){window.location='skin1_delete.php?skin1_id=<?php echo $row["skin1_id"];?>'}" class="text-white bg-gradient-to-r from-red-400 via-red-500 to-red-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 shadow-lg shadow-red-500/50 dark:shadow-lg dark:shadow-red-800/80 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">ลบ</a>
                            <?php
                                    echo '</td>';
                                    echo '</tr>';
                                }
                                mysqli_free_result($result);
                                mysqli_close($conn);
                            ?>
            </tr>
        </tbody>
    </table>
</div>

<footer class="bg-black text-center text-white text-1xl p-6 w-full fixed bottom-0">
    <h1>©2022 Passakorn</h1>
  </footer>

</body>
</html>
