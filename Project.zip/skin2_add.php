<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://cdn.tailwindcss.com"></script>
  <script src="../path/to/flowbite/dist/flowbite.js"></script>
  <script src="./TW-ELEMENTS-PATH/dist/js/index.min.js"></script>
  <script src="https://unpkg.com/flowbite@1.4.0/dist/flowbite.js"></script>
        <title>php-id-w10</title>
    </head>
    <body class="mx-auto">        
    <?php include 'menu.php' ?>
    
    <div class="mb-4 bg-red-100 border-t-4 border-red-500 rounded-b text-red-900 px-4 py-3 shadow-md" role="alert">
  <div class="flex">
    <div class="py-1"><svg class="fill-current h-6 w-6 text-red-500 mr-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z"/></svg></div>
    <div>
      <p class="font-bold">เพิ่มข้อมูลสกิน</p>
    </div>
  </div>

</div>
                <?php
                    if(isset($_GET['submit'])){
                        $skin2_image = $_GET['skin2_image'];
                        $skin2_collectionedition = $_GET['skin2_collectionedition'];
                        $skin2_collection = $_GET['skin2_collection'];
                        $skin2_weapon = $_GET['skin2_weapon'];
                        $skin2_price = $_GET['skin2_price'];
                        $sql = "insert into valorantskin2 (skin2_image,skin2_collectionedition,skin2_collection,skin2_weapon,skin2_price) values ('$skin2_image','$skin2_collectionedition','$skin2_collection','$skin2_weapon','$skin2_price')";
                        include 'connectdb.php';
                        mysqli_query($conn,$sql);
                        mysqli_close($conn);
                        echo "เพิ่มเครื่องมือ เรียบร้อยแล้ว<br>";
                        echo '<a href="skin2_list.php">แสดงเครื่องมือทั้งหมด</a>';
                    }else{
                ?>
<form class="form-horizontal w-1/2" role="form" name="tools_add" action="<?php echo $_SERVER['PHP_SELF']?>">
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        รูปภาพ
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin2_image" id="skin2_image" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-red-500">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        ไอเท็ม
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin2_collectionedition" id="skin2_collectionedition" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-red-500">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        เเทร็ค
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin2_collection" id="skin2_collection" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-red-500">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        เทียร์
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin2_weapon" id="skin2_weapon" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-red-500">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        ราคาพอยท์
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin2_price" id="skin2_price" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-red-500">
    </div>
  </div>
 
  <div class="md:flex md:items-center">
    <div class="md:w-1/3"></div>
    <div class="md:w-2/3">
      <button class="shadow bg-red-500 hover:bg-red-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type="submit" name="submit">
        ยืนยัน
      </button>
    </div>
  </div>
</form>

                <?php
                    }
                ?>
                </div>    
            </div>
        </div> 
    </body>
</html>