<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>php-id-w10-title-edit</title>
        <script src="https://cdn.tailwindcss.com"></script>
  <script src="../path/to/flowbite/dist/flowbite.js"></script>
  <script src="./TW-ELEMENTS-PATH/dist/js/index.min.js"></script>
  <script src="https://unpkg.com/flowbite@1.4.0/dist/flowbite.js"></script>
    </head>
    <body>
<?php include 'menu.php' ?>
 <div class="mb-4 bg-yellow-100 border-t-4 border-yellow-500 rounded-b text-yellow-900 px-4 py-3 shadow-md" role="alert">
  <div class="flex">
    <div class="py-1"><svg class="fill-current h-6 w-6 text-yellow-500 mr-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z"/></svg></div>
    <div>
      <p class="font-bold">เพิ่มข้อมูลสกิน</p>
    </div>
  </div>
</div>

                <?php
                    include 'connectdb.php';
                    if(isset($_GET['submit'])){
                        $skin_id     = $_GET['skin_id'];
                        $skin_image   = $_GET['skin_image'];
                        $skin_collectionedition  = $_GET['skin_collectionedition'];
                        $skin_collection  = $_GET['skin_collection'];
                        $skin_weapon  = $_GET['skin_weapon'];
                        $skin_price   = $_GET['skin_price'];
                        $sql        = "update valorantskin set skin_image='$skin_image',skin_collectionedition='$skin_collectionedition',skin_collection='$skin_collection',skin_weapon='$skin_weapon',skin_price='$skin_price' where skin_id='$skin_id'";
                        mysqli_query($conn,$sql);
                        mysqli_close($conn);
                        echo "เพิ่มคำนำหน้า เรียบร้อยแล้ว<br>";
                        echo '<a href="skin_list.php">แสดงคำนำหน้าชื่อทั้งหมด</a>';
                    }else{
                        $fskin_id = $_REQUEST['skin_id'];
                        $sql =  "SELECT * FROM valorantskin where skin_id='$fskin_id'";
                        $result = mysqli_query($conn,$sql);
                        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                        $fskin_image = $row['skin_image'];
                        $fskin_collectionedition = $row['skin_collectionedition'];
                        $fskin_collection = $row['skin_collection'];
                        $fskin_weapon = $row['skin_weapon'];
                        $fskin_price = $row['skin_price'];
        
                        mysqli_free_result($result);
                        mysqli_close($conn);                        
                ?>
           <form class="form-horizontal w-1/2" role="form" name="title_edit" action="<?php echo $_SERVER['PHP_SELF']?>">
           <input type="hidden" name="skin_id" id="skin_id" value="<?php echo "$fskin_id";?>">
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        รูปภาพ
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin_image" id="skin_image" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-yellow-500" value="<?php echo "$fskin_image";?>">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        ระดับสกิน
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin_collectionedition" id="skin_collectionedition" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-yellow-500" value="<?php echo "$fskin_collectionedition";?>">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        เซ็ตสกิน
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin_collection" id="skin_collection" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-yellow-500" value="<?php echo "$fskin_collection";?>">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        ประเภทอาวุธ
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin_weapon" id="skin_weapon" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-yellow-500" value="<?php echo "$fskin_weapon";?>">
    </div>
  </div>
  <div class="md:flex md:items-center mb-6">
    <div class="md:w-1/3">
      <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
        ราคาพอยท์
      </label>
    </div>
    <div class="md:w-2/3">
      <input type="text" name="skin_price" id="skin_price" class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-yellow-500" value="<?php echo "$fskin_price";?>">
    </div>
  </div>
 
  <div class="md:flex md:items-center">
    <div class="md:w-1/3"></div>
    <div class="md:w-2/3">
      <button class="shadow bg-yellow-500 hover:bg-yellow-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type="submit" name="submit">
        ยืนยัน
      </button>
    </div>
  </div>
</form>
                <?php
                    }
                ?>
         </div>    
            </div>
        </div> 
    </body>
</html>