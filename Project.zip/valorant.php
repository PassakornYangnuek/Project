<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  
  <link rel="stylesheet" type="text/css" href="mystyle1.css">
</head>

 <body class="bg-gray-800">
 <?php include 'menu.php'; ?>
  <header>
    <div class="text-6xl text-center font-extrabold p-8">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h3 class="animate-charcter">VALORANT</h3>
          </div>
        </div>
      </div>
    </div>
    <div class="py-2 flex items-center justify-center space-x-10">
      <iframe class="mb-44" width="900" height="600" src="https://www.youtube.com/embed/bxBvRVEeJX8?autoplay=1&mute=1"></iframe>
</div>
</header>
  <div class="flex justify-center items-center">
      <a href="page1.php" class="relative inline-flex items-center justify-start px-6 py-4 bottom-36 overflow-hidden font-medium transition-all bg-neutral-800 rounded hover:bg-red-400 group">
        <span class="w-48 h-48 rounded rotate-[-40deg] bg-red-600 absolute bottom-0 left-0 -translate-x-full ease-out duration-700 transition-all translate-y-full mb-9 ml-9 group-hover:ml-0 group-hover:mb-32 group-hover:translate-x-0"></span>
        <span class="relative w-full text-left text-red-500 transition-colors duration-300 ease-in-out group-hover:text-white">PLAY VALORANT</span>
        </a>
        </div>
  <footer class="bg-black text-center text-white text-1xl p-6 w-full fixed bottom-0">
    <h1>©2022 Passakorn</h1>
  </footer>

</body>
</html> 