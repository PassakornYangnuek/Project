-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2023 at 06:01 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `valorant`
--

-- --------------------------------------------------------

--
-- Table structure for table `valorantskin`
--

CREATE TABLE `valorantskin` (
  `skin_id` int(11) NOT NULL COMMENT 'ไอดีสกิน',
  `skin_image` varchar(100) NOT NULL,
  `skin_collectionedition` varchar(100) NOT NULL,
  `skin_collection` varchar(100) NOT NULL,
  `skin_weapon` varchar(100) NOT NULL,
  `skin_price` int(11) NOT NULL,
  `skin_detail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `valorantskin`
--

INSERT INTO `valorantskin` (`skin_id`, `skin_image`, `skin_collectionedition`, `skin_collection`, `skin_weapon`, `skin_price`, `skin_detail`) VALUES
(29, 'https://vgraphs.com/images/weapons/valorant-elderflame-frenzy-profile-icon.png', 'Ultra', 'Luxe', 'Oparator', 2475, ''),
(30, 'https://vgraphs.com/images/weapons/skins/valorant-weapon-skin-elderflame-judge-variant-3-dark.png', 'Ultra', 'Elderframe', 'Vandal', 875, ''),
(32, 'https://vgraphs.com/images/weapons/skins/valorant-weapon-skin-elderflame-vandal-variant-3-dark.png', 'Ultra', 'Elderframe', 'Vandal', 2475, ''),
(33, 'https://vgraphs.com/images/weapons/skins/full-details/valorant-elderflame-operator-weapon-skin.png', 'Ultra', 'Elderframe', 'Operator', 2475, ''),
(34, 'https://vgraphs.com/images/weapons/skins/full-details/valorant-elderflame-dagger-weapon-skin.png', 'Ultra', 'Elderframe', 'Dagger', 4950, ''),
(35, 'https://valorantinfo.com/images/th/protocol-781-a-sheriff_valorant_full_skin_154710.webp', 'Ultra', 'Protocol 781-A', 'Sheriff', 2475, ''),
(36, 'https://valorantinfo.com/images/th/protocol-781-a-spectre_valorant_full_skin_154934.webp', 'Ultra', 'Protocol 781-A', 'Specter', 2475, ''),
(41, 'https://valorantinfo.com/images/id/protocol-781-a-phantom_valorant_full_skin_159492.webp', 'Ultra', 'Protocol 781-A', 'Phantom', 2475, ''),
(42, 'https://valorantinfo.com/images/th/personal-administrative-melee-unit_valorant_full_skin_155048.webp', 'Ultra', 'Protocol 781-A', 'Dagger', 4950, ''),
(43, 'https://valorantinfo.com/images/th/protocol-781-a-bulldog_valorant_full_skin_154380.webp', 'Ultra', 'Protocol 781-A', 'Bulldog', 2475, '');

-- --------------------------------------------------------

--
-- Table structure for table `valorantskin1`
--

CREATE TABLE `valorantskin1` (
  `skin1_id` int(11) NOT NULL,
  `skin1_image` varchar(100) NOT NULL,
  `skin1_collectionedition` varchar(100) NOT NULL,
  `skin1_collection` varchar(100) NOT NULL,
  `skin1_weapon` varchar(100) NOT NULL,
  `skin1_price` int(11) NOT NULL,
  `skin1_detail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `valorantskin1`
--

INSERT INTO `valorantskin1` (`skin1_id`, `skin1_image`, `skin1_collectionedition`, `skin1_collection`, `skin1_weapon`, `skin1_price`, `skin1_detail`) VALUES
(1, 'https://valorantinfo.gg/wp-content/uploads/2021/11/valorant-polyfrog-marshal-skin.png', 'POLYfrog Marshal', 'Pass', '1', 500, ''),
(2, 'https://valorantinfo.gg/wp-content/uploads/2021/09/valorant-mic-drop-buddy.png', 'GL Have Cat Buddy', 'Pass', '2', 200, ''),
(3, 'https://valorantinfo.com/images/th/vltr-schematic-card_valorant_art_10031.webp', 'VLT/R Schematic Card', 'Pass', '3', 200, ''),
(4, 'https://valorantinfo.com/images/th/prism-iii-judge_valorant_full_skin_154483.webp', 'Prism III Judge', 'Pass', '4', 500, ''),
(5, 'https://www.valorantinfo.gg/wp-content/uploads/2021/10/valorant-bulldog-schema-player-card.png', 'Bulldog Schema Card', 'Pass', '5', 100, ''),
(6, 'https://vgraphs.com/images/players/cards/titles/valorant-player-card-title-team-player.png', 'Bulldog', 'Pass', '6', 50, ''),
(7, 'https://valorantinfo.gg/wp-content/uploads/2021/10/valorant-lobster-spray.png', 'Do Not Enter Spray', 'Pass', '7', 50, ''),
(8, 'https://valorantinfo.com/images/th/happy-frog-spray_valorant_transparent_icon_3781.webp', 'Happy Frog Spray', 'Pass', '8', 50, ''),
(9, 'https://valorantinfo.gg/wp-content/uploads/2021/10/valorant-polyfrog-player-card-horizontal.png', 'POLYfrog Card', 'Pass', '9', 50, ''),
(10, 'https://valorantinfo.com/images/th/cavalier-stinger_valorant_variant_11514.webp', 'Cavalier Stinger', 'Pass', '10', 200, '');

-- --------------------------------------------------------

--
-- Table structure for table `valorantskin2`
--

CREATE TABLE `valorantskin2` (
  `skin2_id` int(11) NOT NULL,
  `skin2_image` varchar(100) NOT NULL,
  `skin2_collectionedition` varchar(100) NOT NULL,
  `skin2_collection` varchar(100) NOT NULL,
  `skin2_weapon` varchar(100) NOT NULL,
  `skin2_price` int(11) NOT NULL,
  `skin2_detail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `valorantskin2`
--

INSERT INTO `valorantskin2` (`skin2_id`, `skin2_image`, `skin2_collectionedition`, `skin2_collection`, `skin2_weapon`, `skin2_price`, `skin2_detail`) VALUES
(1, 'https://valorantinfo.com/images/th/varnish-bulldog_valorant_variant_7884.webp', 'Varnish Bulldog', 'Pass', '1', 1000, ''),
(2, 'https://valorantinfo.com/images/us/bruno-coin-buddy_valorant_icon_24843.webp', ' Bruno Coin Buddy', 'Pass', '2', 100, ''),
(3, 'https://valorantinfo.com/images/us/rainfall-card_valorant_large_art_10070.webp', 'Rainfall Card', 'Pass', '3', 200, ''),
(4, 'https://valorantinfo.com/images/us/promises-kept-spray_valorant_transparent_icon_3818.webp', 'Promises Kept Spray', 'Pass', '4', 200, ''),
(5, 'https://valorantinfo.com/images/us/yikes-spray_valorant_transparent_icon_3819.webp', 'Yikes Spray', 'Pass', '5', 200, ''),
(6, 'https://valorantinfo.com/images/th/artisan-marshal_valorant_full_skin_154881.webp', 'Artisan Marshal', 'Pass', '6', 700, ''),
(7, 'https://valorantinfo.com/images/th/ep-3-2-coin-buddy_valorant_icon_24895.webp', 'Ep 3 // 2 Coin Buddy', 'Pass', '7', 200, ''),
(8, 'https://valorantinfo.com/images/us/taking-note-card_valorant_art_10067.webp', 'Taking Note Card', 'Pass', '8', 100, ''),
(9, 'https://valorantinfo.com/images/th/varnish-judge_valorant_variant_2035.webp', 'Varnish Judge', 'Pass', '9', 800, ''),
(10, 'https://valorantinfo.com/images/id/artisan-foil_valorant_full_skin_160090.webp', 'Artisan Foil', 'Pass', '10', 2000, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `valorantskin`
--
ALTER TABLE `valorantskin`
  ADD PRIMARY KEY (`skin_id`);

--
-- Indexes for table `valorantskin1`
--
ALTER TABLE `valorantskin1`
  ADD PRIMARY KEY (`skin1_id`);

--
-- Indexes for table `valorantskin2`
--
ALTER TABLE `valorantskin2`
  ADD PRIMARY KEY (`skin2_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `valorantskin`
--
ALTER TABLE `valorantskin`
  MODIFY `skin_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ไอดีสกิน', AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `valorantskin1`
--
ALTER TABLE `valorantskin1`
  MODIFY `skin1_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `valorantskin2`
--
ALTER TABLE `valorantskin2`
  MODIFY `skin2_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
